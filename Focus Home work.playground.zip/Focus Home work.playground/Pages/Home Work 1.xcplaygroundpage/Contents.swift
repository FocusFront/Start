//: [Previous](@previous)

import Foundation

let text = "Hello, Focus next ios dev!"
let letterToCount: Character = "o"

let result = countOccurrence(of: letterToCount, in: text)
print("Кількість літер '\(letterToCount)' в тексті: \(result)")


func countOccurrence(of letter: Character, in text: String) -> Int {
    var count = 0
    for char in text {
        if char == letter {
            count += 1
        }
    }
    return count
}
    
