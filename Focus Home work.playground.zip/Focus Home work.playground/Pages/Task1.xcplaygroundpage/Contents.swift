//: [Previous](@previous)

import Foundation

func generateRandomNumbers() -> [Int] {
    var numbers = [Int]()
    for _ in 1...5 {
        numbers.append(Int.random(in: -100...(-1)))
        numbers.append(Int.random(in: 1...100))
    }
    return numbers
}
var numbersArray = generateRandomNumbers()
numbersArray = numbersArray.map { number in
    return number < 0 ? 0 : number
}
print(numbersArray)
var sum = 0
for number in numbersArray {
    sum += number
}
print("\(sum) -> Сумма")

var minElement = Int.max
var maxElement = Int.min

for number in numbersArray {
    if number < minElement {
        minElement = number
    }
    if number > maxElement {
        maxElement = number
    }
}
print("\(minElement) -> Найменьша")
print("\(maxElement) -> Найбільша")

//: [Next](@next)
