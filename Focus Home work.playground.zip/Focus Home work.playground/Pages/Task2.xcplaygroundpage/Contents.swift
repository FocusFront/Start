//: [Previous](@previous)

import Foundation

let monthsArray = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
var monthsDictionary = [Int: String]()
for (index, month) in monthsArray.enumerated() {
    monthsDictionary[index + 1] = month
    //    Щоб місяці починались с цифри 1 , а не з нуля
}
print("\(monthsDictionary) -> Словник")
var dictionary = ["first": 1, "second": 2, "third": 3, "fourth": 4]
if let firstValue = dictionary["first"], let fourthValue = dictionary["fourth"] {
    dictionary["first"] = fourthValue
    dictionary["fourth"] = firstValue
}
print("\(dictionary) -> Нові значення 4 це 1 , а 1 це 4")

//: [Next](@next)
