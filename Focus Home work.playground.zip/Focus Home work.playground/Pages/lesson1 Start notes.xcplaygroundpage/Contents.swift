import Foundation

//Литерали (буквально)
//"Hello Focus"
//5
//5.5
//true

//test operation
print(type(of: "Hello Focus"))
print(type(of: 5.5))
Double(10)
Int.max
Int.min
UInt8.max

//команди
print("Hello Focus")
//масиви в загальному та явному вигляді

var array = ["a", "b", "c"]
var array2: Array<Int> = [10 , 15, 20]
print(array)
//видаляемо та додаемо до змінної значення лише подібне до початкового типу (String ... Double ...)
array.removeLast()
array.append("e")
print(array)

//змінні *(може змінювати свої данні від початкового, наприклад "String" -> "Focus")
var G = "String"
print(G)
G = "Focus"
print(G)

var Num = 5.5
print(Num)

//dictionary

var dictionary = [
    "a": 10,
    "b": 15,
    "c": 13
]
print(dictionary["b"]!)

print(dictionary["v"] ?? 555)

//Функція
// без параметрів
func printMyName() {
    print ("Pavlo")
}
func print(name: String) {
    print("Focus: \(name)")
}
//func print(name : String, title: String){
//    print("\(title): \(name)" )
//}
//якщо функція має щось повернути то ставиму стрілку та значення що саме

func print(name n: String, _ title: String) -> String {
    print ("Well done" )
    return "\(title): \(n)"
}

printMyName()

print(name: "Pavlo")

print(name: "Pavlo", "IOS Developer")

//Arreys (можливі операції з масивом)
// append - додати елементи , remove - відняти елементи , first,last - перший, останній count - кількість елементів в масиві, isEmpty - дізнатись пустий масив чи ні


